
package inventory;

import java.util.HashMap;
import java.util.Scanner;

public class InventoryManagementSystem {
    private HashMap<String, Integer> inventory = new HashMap<>();

    public void addItem(String item, int quantity) {
        inventory.put(item, inventory.getOrDefault(item, 0) + quantity);
        System.out.println(quantity + " " + item + "(s) added.");
    }

    public void removeItem(String item, int quantity) {
        if (inventory.containsKey(item) && inventory.get(item) >= quantity) {
            inventory.put(item, inventory.get(item) - quantity);
            System.out.println(quantity + " " + item + "(s) removed.");
        } else {
            System.out.println("Not enough stock or item doesn't exist.");
        }
    }

    public void viewInventory() {
        System.out.println("Current Inventory:");
        inventory.forEach((item, quantity) -> System.out.println(item + ": " + quantity));
    }

    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nInventory Management System");
            System.out.println("1. Add Item\n2. Remove Item\n3. View Inventory\n4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter item name: ");
                    String addItem = scanner.nextLine();
                    System.out.print("Enter quantity: ");
                    int addQty = scanner.nextInt();
                    ims.addItem(addItem, addQty);
                    break;
                case 2:
                    System.out.print("Enter item name: ");
                    String removeItem = scanner.nextLine();
                    System.out.print("Enter quantity: ");
                    int removeQty = scanner.nextInt();
                    ims.removeItem(removeItem, removeQty);
                    break;
                case 3:
                    ims.viewInventory();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
