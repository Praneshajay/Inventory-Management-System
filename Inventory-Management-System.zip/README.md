
# Inventory Management System

This project is a simple Java-based application for managing inventory in a warehouse or retail environment.

## Features
- Add items with quantities to inventory.
- Remove items from inventory.
- View current inventory with item names and quantities.

## Technologies Used
- **Programming Language**: Java
- **Database**: None (uses in-memory storage for simplicity)
- **Framework**: JavaFX (future expansion possible)

## How to Run
1. Compile the code using `javac`.
2. Run the `InventoryManagementSystem` class.

## Author
This project was created as part of a computer programming curriculum.
